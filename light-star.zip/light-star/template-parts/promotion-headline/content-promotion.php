<?php
/**
 * The template used for displaying hero content
 *
 * @package ScapeShot
 */
?>

<?php
$scapeshot_enable_section = get_theme_mod( 'scapeshot_promo_head_visibility', 'disabled' );

if ( ! scapeshot_check_section( $scapeshot_enable_section ) ) {
	// Bail if hero content is not enabled
	return;
}

get_template_part( 'template-parts/promotion-headline/post-type', 'promotion' );
